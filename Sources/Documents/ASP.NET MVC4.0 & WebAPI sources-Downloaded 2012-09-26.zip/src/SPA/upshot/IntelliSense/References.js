﻿/// <reference path="Dependencies.js" />
/// <reference path="..\Core.js" />
/// <reference path="..\AssociatedEntitiesView.js" />
/// <reference path="..\Upshot.Compat.jQueryUI.js" />
/// <reference path="..\Upshot.Compat.JsViews.js" />
/// <reference path="..\Upshot.Compat.Knockout.js" />
/// <reference path="..\Upshot.Compat.WinJS.js" />
/// <reference path="..\DataContext.js" />
/// <reference path="..\DataProvider.js" />
/// <reference path="..\DataProvider.OData.js" />
/// <reference path="..\DataProvider.datacontroller.js" />
/// <reference path="..\DataProvider.json.js" />
/// <reference path="..\DataSource.js" />
/// <reference path="..\EntitySet.js" />
/// <reference path="..\EntitySource.js" />
/// <reference path="..\EntityView.js" />
/// <reference path="..\LocalDataSource.js" />
/// <reference path="..\Observability.js" />
/// <reference path="..\RemoteDataSource.js" />

// This file enables VS IntelliSense in JavaScript, otherwise it can be removed 