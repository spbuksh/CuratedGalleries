
// ======================================================================================
// VARIABLES
// ======================================================================================

	// System variables
	var currScene = 0;
	var screenWidth = 0;
	var screenHeight = 0;
	var stageWidth = 1024;
	var stageHeight = 662;
	var isLoading = true;
	var currSlide = 1;
	var isContentVisible = true;
	var slideBlocker = false;
	var touchState = false;
	
	
	
	// Configuration
	var slideAmount = 5;
	
	
	
	// Game Objects (HTML5 tags)
	var stage;
	
	var preloaderIcon;
	var preloaderWall;
	
	var scrollArea;
	
	var leftButton;
	var rightButton;
	
	var showHideButton;

// ======================================================================================





// ======================================================================================
// MAIN EVENT HANDLERS
// ======================================================================================

	// Event Handler initialisation
	addEvent(window, 'load', loadHandler);
	addEvent(document, 'touchstart', function (e) { e.preventDefault(); });
	
	
	
	// Main handler that gets called when page is loaded
	function loadHandler() {

		loadObjects();
		
		showScene('load');
		
		preloader();
		
	}
	
	
	// Function that initialises game after preloader is complete
	function init() {
		if (isLoading == false) {
						
			setTimeout(function () {
				positionObjects();
				
				showScene('gallery');
				
			}, 100);
		}
	}
	
// ======================================================================================





// ======================================================================================
// LOADING SCENE CONTROL
// ======================================================================================
	var images = 		["gallery-image1.jpg", "gallery-image2.jpg", "gallery-image3.jpg", "gallery-image4.jpg", "gallery-image5.jpg",
					"gallery-content1.png", "gallery-content2.png", "gallery-content3.png", "gallery-content4.png", "gallery-content5.png"];
	var preloaderStarted = false;
	var preloaderDone = 0;
	var imageObj = [];
	
	
	// Preloader function
	function preloader() {

		updateScreenSize ();
		
		var imageToUse;
		
		if (preloaderStarted == false) {
			for(i=0; i<images.length; i++) {
				
				// Create object
				imageObj[i] = new Image(); 
				imageObj[i].src = "images/" + images[i];
				imageObj[i].onload = function () { preloaderDone = preloaderDone + 1; }
			}
		}
		
		preloaderStarted = true;
		
		if (preloaderDone < images.length) {
			setTimeout(function() {
				preloader();
			}, 10);
		} else {
			setTimeout(function() {
				setTimeout(function() { preloaderWall.style.display = 'none'; },100);
				isLoading = false;

				init();
			}, 0);
			
		}

	}
// ======================================================================================





// ======================================================================================
// GALLERY SCENE CONTROL
// ======================================================================================

	var prevSlide = 0;
	var transitionSpeed = 1000;

	// Function that initialises Start Scene
	function initGalleryScene () {
		addEvent(leftButton, 'touchend', leftClickHandler);
		addEvent(rightButton, 'touchend', rightClickHandler);
		addEvent(leftButton, 'click', leftClickHandler);
		addEvent(rightButton, 'click', rightClickHandler);
		
		
		addEvent(showHideButton, 'click', function () {
			if (isContentVisible) { showContent(false); } else { showContent(true); }
		});
		addEvent(showHideButton, 'touchend', function () {
			if (isContentVisible) { showContent(false); } else { showContent(true); }
		});
		
		
		addEvent(scrollArea, 'touchstart', touchStartHandler);
		addEvent(scrollArea, 'touchmove', touchMoveHandler);
		addEvent(scrollArea, 'touchend', touchEndHandler);
		
		addEvent(scrollArea, 'mousedown', mouseDownHandler);
		addEvent(scrollArea, 'mousemove', mouseMoveHandler);
		addEvent(scrollArea, 'mouseup', touchEndHandler);
		addEvent(document, 'mouseup', touchEndHandler);
		
		showContent(true);
	}
// ======================================================================================





// ======================================================================================
// CONTROL HANDLERS
// ======================================================================================

	var startTouchX = 0;
	var moveTouchX = 0;
	var slideDiff = 0;

	// Touch and Click START handlers
	// ---------------------------------
	function touchStartHandler (event) {
		if (slideBlocker == false) {
			event.preventDefault();
			
			var touch = event.touches[0];
			startTouchX = touch.pageX;
			touchState = true;
		}
	}
	
	function mouseDownHandler (event) {
		event.preventDefault();
		
		startTouchX = event.clientX;
		touchState = true;
	}
	
	
	
	
	
	// Touch and Click MOVE handlers
	// ---------------------------------
	
	function touchMoveHandler (event) {
		if (touchState) {
			event.preventDefault();
			
			var touch = event.touches[0];
			moveTouchX = touch.pageX;
			
			slideDiff = moveTouchX - startTouchX;
			if (moveTouchX < startTouchX) {
				gradualSlide(slideDiff, 'right');
			} else if (moveTouchX > startTouchX) {
				gradualSlide(slideDiff, 'left');
			}
		}
	}
	
	function mouseMoveHandler (event) {
		if (touchState) {
			moveTouchX = event.clientX;
			
			slideDiff = moveTouchX - startTouchX;
			if (moveTouchX < startTouchX) {
				gradualSlide(slideDiff, 'right');
			} else if (moveTouchX > startTouchX) {
				gradualSlide(slideDiff, 'left');
			}
		
		}
	}
	
	
	
	
	
	// Touch and Click END handlers
	// ---------------------------------
	
	function touchEndHandler (event) {
		event.preventDefault();
		
		slideDiff = moveTouchX - startTouchX;

		if (touchState) {
			if (moveTouchX > 0) {
				if (moveTouchX+200 < startTouchX) {
					moveSlide (slideDiff, 'right', transitionSpeed, 'swing'); 
				} else if (moveTouchX-200 > startTouchX) {
					moveSlide (slideDiff, 'left', transitionSpeed, 'swing'); 
				} else if (moveTouchX < startTouchX) {
					returnSlide (slideDiff, 'right', (transitionSpeed/4), 'swing')
				} else if (moveTouchX > startTouchX) {
					returnSlide (slideDiff, 'left', (transitionSpeed/4), 'swing')
				} 
			}
			
			touchState = false;
			
			startTouchX = 0;
			moveTouchX = 0;
			prevPos = 0;
		}
	}
	
	
	
	
	
	// Left and Right button Handlers
	// ---------------------------------
	
	function leftClickHandler(event) {
		moveSlide (0, 'left', transitionSpeed, 'swing') 
	}
	
	function rightClickHandler(event) {
		moveSlide (0, 'right', transitionSpeed, 'swing') 
	}
	
// ======================================================================================	





// ======================================================================================
// Slide control methods
// ======================================================================================

	var prevPos = 0;
	
	
	// Function that is called when user is gradually sliding the frame
	function gradualSlide(pos, side) {
		
		if (slideBlocker == false) {
			var thresholdCheck = (side == 'left') ? currSlide > 1 : ((side == 'right') ? currSlide < slideAmount : false);
			var slideSelect = (side == 'left') ? -1 : ((side == 'right') ? +1 : 0);
			var imageSelect = (side == 'left') ? 0 : ((side == 'right') ? +1 : 0);
	
			if (thresholdCheck) {
				
				var newPos = pos - prevPos;
				prevPos = pos;
				
				//console.log('newPos: '+ newPos + ' | Curr Pos: '+ $('#gallery-slide'+currSlide).position().left);
				
				$('#gallery-slide'+currSlide).animate({
					left: '+='+newPos + 'px'
				}, 0, 'linear');
				
				$('#gallery-slide'+(currSlide+slideSelect)).animate({
					left: '+='+newPos + 'px'
				}, 0, 'linear');
				
				executeFixedPosition (side, 0, 'linear', true, newPos);
				
				
				$('#gallery-image'+(currSlide+imageSelect)).animate({
					left: '-='+newPos/2 + 'px'
				}, 0, 'linear');	
				
				
				if (($('#gallery-image'+(currSlide+imageSelect)).position().left < getInitImagePos(currSlide+imageSelect)) && (side == 'left')) {
					$('#gallery-image'+(currSlide+imageSelect)).css({'left': getInitImagePos(currSlide+imageSelect)+'px'});
				} else if (($('#gallery-image'+(currSlide+imageSelect)).position().left > (getInitImagePos(currSlide+imageSelect)+350)) && (side == 'right')) {
					$('#gallery-image'+(currSlide+imageSelect)).css({'left': (getInitImagePos(currSlide+imageSelect)+350)+'px'});
				}
			}
		}
	}
	

	// Function that is called when user either releases mouse/touch or when clicks on a button to go to next slide. 
	// This executes full animation to go to next slide.
	function moveSlide (diffMoved, side, speed, easing) {
		
		var thresholdCheck = (side == 'left') ? currSlide > 1 : ((side == 'right') ? currSlide < slideAmount : false);
		var slideSelect = (side == 'left') ? '+=' : ((side == 'right') ? '-=' : '');
		
		if (thresholdCheck) {
			if (slideBlocker == false) {
				slideBlocker = true;
				
				prevSlide = currSlide; 
				currSlide = (side == 'left') ? currSlide-1 : ((side == 'right') ? currSlide+1 : 0);
				
				var imageSelect = (side == 'left') ? '-=' : ((side == 'right') ? '+=' : '');
				var imageSlideSelect = (side == 'left') ? prevSlide : ((side == 'right') ? currSlide : '');
				
				
				
				/*console.log('startTouchX:' + startTouchX + ' | moveTouchX: '+ moveTouchX + ' | slideDiff: '+ diffMoved);
				console.log('Curr Pos: '+ $('#gallery-slide'+currSlide).position().left);
				console.log('To Add: '+ (1024-Math.abs(diffMoved)) + ' | Final Val: '+ ($('#gallery-slide'+currSlide).position().left - (1024-Math.abs(diffMoved))));
				*/
				
				$('#gallery-slide'+currSlide).animate({
					left: slideSelect+(1024-Math.abs(diffMoved)) + 'px'
				}, speed, easing, function () { 
					
					fixPos('main');
					
				});
				
		
				$('#gallery-slide'+prevSlide).animate({
					left: slideSelect+(1024-Math.abs(diffMoved)) + 'px'
				}, speed, easing, function () { 
						fixPos('around-slides');
					});
				
				executeFixedPosition (side, speed, easing, false, diffMoved);
				
				if (isContentVisible) {
					
					$imageObj = $('#gallery-image'+(imageSlideSelect));
				
					if (($imageObj.position().left < getInitImagePos(imageSlideSelect)) && (side == 'left')) {
						$imageObj.css({'left': getInitImagePos(imageSlideSelect)+'px'});
					}
					else if (($imageObj.position().left > (getInitImagePos(imageSlideSelect)+350)) && (side == 'right')) {
						$imageObj.css({'left': (getInitImagePos(imageSlideSelect)+350)+'px'});
					} else if ($imageObj.position().left != (getInitImagePos(imageSlideSelect)+350)) {
						
						$imageObj.animate({
							left: imageSelect+(350-Math.abs(diffMoved/2)) + 'px'
						}, speed, easing, function () { 
							fixPos('main-image');
						});
					}
					

				} else {	
					var imgWidth = $('#gallery-image'+currSlide).width();
					centerPos = ((stageWidth-imgWidth) /2);
					$('#gallery-image'+currSlide).animate({left: centerPos + 'px'}, speed, easing);
				} 	
				
			}
		}
	}
	

	// Function that is called when gradual slide doesn't go fully to position that is set to change slides. Then it returns the slide back.
	function returnSlide (diffMoved, side, speed, easing) {

		var thresholdCheck = (side == 'left') ? currSlide > 1 : ((side == 'right') ? currSlide < slideAmount : false);
		var slideDirSelect = (side == 'left') ? '-=' : ((side == 'right') ? '+=' : '');
		var slideSelect = (side == 'left') ? -1 : ((side == 'right') ? +1 : 0);
		var imageSelect = (side == 'left') ? 0 : ((side == 'right') ? 1 : 0);
		var imageDirSelect = (side == 'left') ? '+=' : ((side == 'right') ? '-=' : '');
		
		if (thresholdCheck) {
			if (slideBlocker == false) {
				slideBlocker = true;			
			
				$('#gallery-slide'+currSlide).animate({
					left: slideDirSelect+(Math.abs(diffMoved)) + 'px'
				}, speed, easing, function () { 
					fixPos('main');
				});
						
				
				$('#gallery-slide'+(currSlide+slideSelect)).animate({
					left: slideDirSelect+Math.abs(diffMoved) + 'px'
				}, speed, easing, function () { 
						fixPos('around-slides');
					});
						
				executeFixedPosition (side, speed, easing, true, -diffMoved);
						
				if (isContentVisible) {
					
					$('#gallery-image'+(currSlide+imageSelect)).animate({
						left: imageDirSelect+Math.abs(diffMoved/2) + 'px'
					}, speed, easing, function () { 
						fixPos('main-image');
					});
		
				} else {	
			
					var imgWidth = $('#gallery-image'+currSlide).width();
					centerPos = ((stageWidth-imgWidth) /2);
					$('#gallery-image'+currSlide).animate({left: centerPos + 'px'}, speed, easing);
							
				} 
			}
		}	
	}
	
	
	// Function that fixes the position. This is called after each end of animation to fix the position of the slide.
	function fixPos(type) {
		switch (type) {
			case 'main': 			$('#gallery-slide'+currSlide).animate({'left': '0px'}, 100, function () { 
																									slideBlocker = false; 
																									fixPos('fixed-position');
																								});
									break;
							
			case 'main-image': 		for (var i = 1; i <= slideAmount; i++) {
										if (i == currSlide) {
											$('#gallery-image'+i).animate({'left': (350-Math.abs(getInitImagePos(i)))+'px'}, 100);
										} else {
											if (i < currSlide) {
												$('#gallery-image'+i).animate({'left': (350+getInitImagePos(i))+'px'}, 100);
											} else if (i > currSlide) {
												$('#gallery-image'+i).animate({'left': (getInitImagePos(i))+'px'}, 100);
											}
											
										}
									}
									break;
		
			case 'around-slides': 	for (var i = 1; i <= slideAmount; i++) {
										if (i < currSlide)
											$('#gallery-slide'+i).animate({'left': '-1024px'}, 100);
											
										if (i > currSlide)
											$('#gallery-slide'+i).animate({'left': '1024px'}, 100);
									}
									
									break;
		
			case 'fixed-position': 	for (var i = 1; i <= slideAmount; i++) {
										if ($('#gallery-content'+ i).hasClass('pos-fixed')) {
											if (currSlide == i) {
												setObjPos('gallery-content', i);
												
												if (currSlide != 1)
													$('#gallery-content'+i).animate({'left': '+=1024'}, 0);
											}
										}
									}
									
									
									break;
		}
	}
	
// ======================================================================================





// ======================================================================================
// CONTROL FUNCTIONS
// ======================================================================================
	
	// Function that iterates through slides on the way to reach and show the slide that is defined by id.
	var showSlideInterval;
	function showSlide(id) {
		if (slideBlocker == false) {
			if (currSlide < id) {
				showSlideInterval = setInterval(function () { 
													
													moveSlide (0, 'right', 250, 'linear'); 
													
													slideBlocker = true;
													
													if (currSlide == id) {
														slideBlocker = false;
														clearInterval(showSlideInterval); 
													}
												}, 1);
			} else if (currSlide > id) {
				showSlideInterval = setInterval(function () { 
													
													moveSlide (0, 'left', 250, 'linear'); 
													slideBlocker = true;
													if (currSlide == id) {
														slideBlocker = false;
														clearInterval(showSlideInterval);
													}
												}, 1);
			}
		}
	}


	// Function that's when called shows or hides the content depending on the val variable(true - shows | false - hides).
	// It also reprocesses new positions of images.
	function showContent (val) {
		
		if (slideBlocker == false) {
			slideBlocker = true;
			
			var centerPos = 0;
			var imgWidth = 0;
			
			
			if (val) {
				isContentVisible = true;
				for (var i = 1; i <= slideAmount; i++) {
					$('#gallery-content'+i).fadeIn(500, function () { slideBlocker = false; });
					
					imgWidth = $('#gallery-image'+i).width();
					
					if (imgWidth < 1024) {
						if (i == currSlide) {
							centerPos = ((stageWidth-imgWidth) /2);
							if ($('#gallery-content'+i).hasClass('pos-left')) {
								$('#gallery-image'+i).animate({left: '+='+centerPos+'px'}, 500);
								
							} else if ($('#gallery-content'+i).hasClass('pos-right')) {
								$('#gallery-image'+i).animate({left: '-='+centerPos+'px'}, 500);
							}
						} else if (i > currSlide) {
							$('#gallery-image'+i).animate({left: getInitImagePos(i)+'px'}, 500);
						} else if (i < currSlide) {
							$('#gallery-image'+i).animate({left: (350-getInitImagePos(i))+'px'}, 500);
						}
					}
				}
				
			} else {
				isContentVisible = false;
				for (var i = 1; i <= slideAmount; i++) {
					$('#gallery-content'+i).fadeOut(500, function () { slideBlocker = false; });
					
					imgWidth = $('#gallery-image'+i).width();
					
					if (imgWidth < 1024) {
						if (i == currSlide) {
							centerPos = ((stageWidth-imgWidth) /2);
							$('#gallery-image'+i).animate({left: centerPos+'px'}, 500);
						} else {
							
						}
					}
				}
			}
		}
	}
// ======================================================================================





// ======================================================================================
// SYSTEM FUNCTIONS
// ======================================================================================
	
	// Function that processes content elements that are fixed to position.
	function executeFixedPosition (side, speed, easing, isGradual, gradualPos) {
		
		var valueToAdd = 0;
		if (isGradual) {
			if (side == "right") {
				valueToAdd = -gradualPos;
			} else {
				valueToAdd = gradualPos;
			}
		} else {
			if (gradualPos) {
				valueToAdd = 1024 - Math.abs(gradualPos);
			} else {
				valueToAdd = 1024;
			}
		}
		
		for (var i = 1; i <= slideAmount; i++) {
			if ($('#gallery-content'+i).hasClass("pos-fixed")) {
				if (side == 'right') {
					if ((!isGradual) && (i == prevSlide || i == currSlide)) {
						$('#gallery-content'+i).animate({left: '+='+valueToAdd}, speed, easing);	
					
					} else if ((isGradual) && (i == currSlide)) {
						$('#gallery-content'+(currSlide)).animate({left: '+='+valueToAdd}, speed, easing);	
						
					} else if ((isGradual) && (i == currSlide+1)) {
						$('#gallery-content'+(currSlide+1)).animate({left: '+='+valueToAdd}, speed, easing);	
					} 
					
					
				} else if (side == 'left') {
					
					if ((!isGradual) && (i == prevSlide || i == currSlide)) {
						$('#gallery-content'+i).animate({left: '-='+valueToAdd}, speed, easing);	
					
					} else if ((isGradual) && (i == currSlide)) {
						$('#gallery-content'+(currSlide)).animate({left: '-='+valueToAdd}, speed, easing);	
						
					} else if ((isGradual) && (i == currSlide-1)) {
						$('#gallery-content'+(currSlide-1)).animate({left: '-='+valueToAdd}, speed, easing);	
					} 
				}

			}
		}
		
	}
	
	
	// Function that positions all images to appropriate position
	function positionImages () {
		
		for (var i = 1; i <= slideAmount; i++) {
			
			
			if (i != 1)
				$('#gallery-image'+i).css({'left': getInitImagePos(i)+'px'});
		}
	}
	
	
	// Gets position of image where it should be positioned.
	function getInitImagePos (id) {
		var posX = -350;
		
		if ($('#gallery-content'+id).hasClass('pos-left')) {
			posX = posX + $('#gallery-content'+id).width();
		}
		
		return posX;
	}
	
	
	// Positions all content objects
	function positionObjects () {
		for (var i = 1; i <= slideAmount; i++) {
			setObjPos('gallery-content', i);
		}
		
		positionImages ();
	}
	
	
	// Positions content objects depending on which class they have been set to.
	function setObjPos(obj, id) {
		$obj = $('#'+ obj + id);
		var fixedValue = 0;
		
		if ($obj.hasClass('pos-fixed')) {
			if (id != 1) 
				fixedValue = -1024;
		}
		
		if ($obj.hasClass('pos-left')) {
			var newPos = 0 + fixedValue;
			$obj.css({'left': newPos+'px'});
			
		} else if ($obj.hasClass('pos-left-100')) {
			var newPos = 100 + fixedValue;
			$obj.css({'left': newPos+'px'});
			
		} else if ($obj.hasClass('pos-right')) {
			var newPos = (1024 - $obj.width()) + fixedValue;
			$obj.css({'left': newPos+'px'});
			
		} else if ($obj.hasClass('pos-right-100')) {
			var newPos = ((1024 - $obj.width())-100) + fixedValue;
			$obj.css({'left': newPos+'px'});
			
		} else if ($obj.hasClass('pos-h-mid')) {
			var newPos = ((1024 - $obj.width())/2) + fixedValue;
			$obj.css({'left': newPos+'px'});
			
		}
		
		
		if ($obj.hasClass('pos-top')) {
			$obj.css({'top': '0px'});
			
		} else if ($obj.hasClass('pos-top-100')) {
			$obj.css({'top': '100px'});
			
		} else if ($obj.hasClass('pos-bottom')) {
			var newPos = (662 - $obj.height());
			$obj.css({'top': newPos+'px'});
			
		} else if ($obj.hasClass('pos-bottom-100')) {
			var newPos = (662 - $obj.height())-100;
			$obj.css({'top': newPos+'px'});
			
		} else if ($obj.hasClass('pos-v-mid')) {
			var newPos = (662 - $obj.height())/2;
			$obj.css({'top': newPos+'px'});
			
		}
	}


	// Function that initialises and assigns all objects to variables
	function loadObjects () {
		stage = document.getElementById('stage');
		
		preloaderIcon = document.getElementById('preloader-icon');
		preloaderWall = document.getElementById('preloader-wall');
		
		scrollArea = document.getElementById('scroll-area');
		
		leftButton = document.getElementById('left-button');
		rightButton = document.getElementById('right-button');
		
		showHideButton = document.getElementById('show-hide-button');

	}
	
	
	// Function that shows scene when called using the scene ID
	function showScene (id) {
		var prevScene = currScene;
		currScene = id;
		
		if (prevScene != 0) 
	    	$('#'+ prevScene + '-scene').fadeOut(500);
		
		
		$('#'+ currScene + '-scene').fadeIn(500);
		
		switch (currScene) {
			case 'gallery':
					initGalleryScene();
					break;
		}
	}


	// Updates screen size of device including moving toolbar and picking up resolution
	function updateScreenSize () {
		 delayTime = 0;
		 
		setTimeout(function () {
				
			screenWidth = window.innerWidth;
			screenHeight = window.innerHeight; 
			
		}, delayTime);
		
	}

	
// ======================================================================================
