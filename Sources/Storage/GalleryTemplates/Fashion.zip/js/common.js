var addEvent = function(object, eventType, handler) {
  if (object.addEventListener) {
    // Firefox, Google Chrome and Safari (and Opera and Internet Explorer from
    // version 9).
    object.addEventListener(eventType, handler, false);
    return true;
  } else if (object.attachEvent) {
    // Opera and Explorer (version < 9).
    return object.attachEvent('on' + eventType, handler);
  } else {
    return false;
  }
};


var removeEvent = function(object, eventType, handler) {
  if (object.removeEventListener) {
    // Firefox, Google Chrome and Safari (and Opera and Internet Explorer from
    // version 9).
    object.removeEventListener(eventType, handler, false);
    return true;
  } else if (object.detachEvent) {
    // Opera and Explorer (version < 9).
    return object.detachEvent('on' + eventType, handler);
  } else {
    return false;
  }
};
