/**
 * Created with JetBrains PhpStorm.
 * User: Alex
 * Date: 24.10.12
 * Time: 8:25
 * To change this template use File | Settings | File Templates.
 */
$(document).ready(function(){
    text_position();
})
function text_position(){
    var curCheck = $('.radioGroup :radio:checked').attr('id');
    $('div.'+curCheck).show().siblings().hide();
    $('.radioGroup :radio').click(function(){
        var activeRadio = $(this).attr('id');
        $('div.'+activeRadio).show().siblings().hide();
    })
}